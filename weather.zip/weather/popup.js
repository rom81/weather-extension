var jsonData;

var city = prompt("Enter a city: ");
$.getJSON("http://api.openweathermap.org/data/2.5/weather?q=" + city + "&units=imperial&appid=c3ec46e0a4c33ca46821a76492688dcc", function(json) {

	jsonData = json;

	// organize data
	var temp = jsonData.main.temp;
	var main = jsonData.weather[0].main;						
	var humidity = jsonData.main.humidity;
	var percentCloudiness = jsonData.clouds.all;
	
	// set humidity
	document.getElementById("humidity").innerHTML = "Humidity: " + humidity + "%";

	// set city
	document.getElementById("city").innerHTML = city;

	// set weather description
	document.getElementById("weather").innerHTML = "Condition: " + main;


	// set background image
	if (main == "Clouds") {
		document.body.style.backgroundImage = "url('http://www.gazetteseries.co.uk/resources/images/5360796/')";
	} else if (city == "Pittsburgh" && main == "Clouds") {
		document.body.style.backgroundImage = "url('https://s-media-cache-ak0.pinimg.com/736x/93/49/9a/93499a5d5e0dcf0e67cb880ee8735ff4.jpg')";
	} else if (main == "Rain") {
   		document.body.style.backgroundImage = "url('https://rain.today/Pix/rain.jpg')";
   	} else if (main == "Clear") {
   		document.body.style.backgroundImage = "url('https://c.tadst.com/gfx/750w/sunrise-sunset-sun-calculator.jpg?1')";
   	} else if (main == "Snow") {
   		document.body.style.backgroundImage = url('https://everymansurvival.files.wordpress.com/2015/07/spruce_trees_covered_in_heavy_snow.jpg');
   	}


   	// set temperature 
   	if (temp < 20) {
   		document.getElementById("temperature").innerHTML = "Stay inside, kids. It's " + temp + " F. Brr." ;
   	} else if (temp <= 40) {
   		document.getElementById("temperature").innerHTML = "Bundle up! It's " + temp + " F." ;
   	} else if (temp > 40 && temp < 60) {
		document.getElementById("temperature").innerHTML = "Bring a jacket today. <br> It's " + temp + " F.";
	} else if (temp >= 60 && temp < 70) {
		document.getElementById("temperature").innerHTML = "It's cool today, only " + temp + " F";
	} else if (temp >= 70 && temp < 80) {
		document.getElementById("temperature").innerHTML = "It's a beautiful day! " + temp + " F";
	} else if (temp >= 80 && temp < 90) {
		document.getElementById("temperature").innerHTML = "Hot, hot, hot!! " + temp + " F." ;
	} else if (temp >= 90) {
		document.getElementById("temperature").innerHTML = "It's REALLY hot. " + temp + " F";
	}
	


});



	
