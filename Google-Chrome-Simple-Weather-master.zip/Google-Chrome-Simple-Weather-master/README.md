# Google Chrome - Start Weather

Chrome extension that displays the weather using a free weather API provided by Yahoo.

<!--Install from: https://chrome.google.com/extensions/detail/dkgcomhcmhlbdokplmbpkejkojkmjglg-->

**Features:**

The feed is automatically using the current system's language setting for the response info.  
Multiple locations that can be set/changed  
Option for Celsius or Fahrenheit display  
Option to have links to weather.Yahoo.com and Weatherunderground.com  
Option for background refresh (1, 2, 3, 4 or 6 hours)  
Option for weather date and/or last check date.  

**Features to be implemented:**  

Moon phases

**Stay tuned!**
